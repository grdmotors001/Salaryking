# Salary King

Customer-facing Salary King website starter.

## Included
- Responsive landing page
- Salary King branding/logo
- Loan application UI
- How it works
- Eligibility/documents section
- Powered by Capital Hind Finance Private Limited
- Ready for Vercel/static hosting

## Next integration
Connect the application form to the Salary King backend/Supabase workflow and add privacy/terms pages before production use.
